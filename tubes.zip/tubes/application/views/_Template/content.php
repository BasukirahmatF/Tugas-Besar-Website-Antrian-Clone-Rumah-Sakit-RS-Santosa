<!-- Begin Page Content -->
<div class="container-fluid">
    <?php echo $isi; ?>
</div