<!DOCTYPE html>
<html lang="en">
<style>
    .main-content{
	width: 50%;
	border-radius: 20px;
	box-shadow: 0 5px 5px rgba(0,0,0,.4);
	margin: 5em auto;
	display: flex;
}
.company__info{
	background-color: #00398c;
	border-top-left-radius: 20px;
	border-bottom-left-radius: 20px;
	display: flex;
	flex-direction: column;
	justify-content: center;
	color: #fff;
}
.company__logo{
	display: flex;
	flex-direction: column;
    justify-content: center;
}
.company__logo .image
{
    position: center;
    width: 80%;
    height: auto;
    padding-left: 10mm;
}
 
@media screen and (max-width: 640px) {
	.main-content{width: 90%;}
	.company__info{
		display: none;
	}
	.login_form{
		border-top-left-radius:20px;
		border-bottom-left-radius:20px;
	}
}
@media screen and (min-width: 642px) and (max-width:800px){
	.main-content{width: 70%;}
}
.row > h2{
	color:#00398c;
}
.login_form{
	background-color: #fff;
	border-top-right-radius:20px;
	border-bottom-right-radius:20px;
	border-top:1px solid #ccc;
	border-right:1px solid #ccc;
}
form{
	padding: 0 2em;
}
.form__input{
	width: 100%;
	border:0px solid transparent;
	border-radius: 0;
	border-bottom: 1px solid #aaa;
	padding: 1em .5em .5em;
	padding-left: 2em;
	outline:none;
	margin:1.5em auto;
	transition: all .5s ease;
}
.form__input:focus{
	border-bottom-color:  #00398c;
	box-shadow: 0 0 5px rgba(0,80,80,.4); 
	border-radius: 4px;
}
.btn{
	transition: all .5s ease;
	width: 70%;
	border-radius: 30px;
	color:#00398c;
	font-weight: 600;
	background-color: #fff;
	border: 1px solid #00398c;
	margin-top: 1.5em;
	margin-bottom: 1em;
}
.btn:hover, .btn:focus{
	background-color: #00398c;
	color:#fff;
}
</style>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LOGIN - Aplikasi Antrian Rsantosa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

</head>
<body>
<div class="container-fluid">
        <div class="row main-content text-center">
            <div class="col-md-4 text-center company__info">
                <span class="company__logo"><img src="/tubes/assets/img/santosa_hospital_fb.png" class="img-fluid image" alt=""></span>
               </div>
                <div class="col-md-8 col-xs-12 col-sm-12 login_form ">
                <div class="container-fluid">
                    <div class="row mt-5">
                        
                        <h2>Log In</h2->
                    </div>
                    <div class="row">
        <form class="form-group" id="login" name="login" action="<?php echo base_url('Login/cek_log'); ?>" method="post">
        <div class="row">
            <label for="username" >Username</label>
            <input type="text" id="username" name="txt_user" class="form__input" placeholder="Masukkan Username anda..." required autofocus>
            </div>
            <div class="row">
            <label for="password">Password</label>
            <input type="password" id="password" name="txt_pass" class="form__input" placeholder="Masukkan Password anda..." required>
            </div>
            
            <?php echo $this->session->flashdata('pesan'); ?>
            <div class="row">
            <input  type="submit" name="btn_log" value="LOGIN" class="btn">
            </div>
            <div class="row">
            <a href="<?php echo base_url('Welcome'); ?>" class="btn" name="kembali">Kembali</a>
          
        </div>
            
        </form>
        
                      
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>

</html>